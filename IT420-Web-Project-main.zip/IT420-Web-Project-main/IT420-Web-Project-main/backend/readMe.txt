This is the folder for the backend!

To run the backend in dev mode to continuously refresh server and see changes made live on website with:

"npm run devStart" in IT420-WEB-PROJECT/backend

NOTE: If "permission denied" error occurs from running above command, try reinstalling nodemon 
globally on your system using:

"sudo npm install -g nodemon" though I'm fairly certain this only occurred for me kepuz I'm on a Mac.