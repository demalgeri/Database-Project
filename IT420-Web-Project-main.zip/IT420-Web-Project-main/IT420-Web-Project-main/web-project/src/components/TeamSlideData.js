//this is for all of the images that are going to be mapped in the team slideshow page.

const teamSlideData = [

    {
        //Vickee
        image: 'https://static.wixstatic.com/media/6e56dc_b59d8fd4e92d49e49ae904b51d0a7187~mv2.jpg/v1/crop/x_0,y_88,w_1090,h_1507/fill/w_162,h_224,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/6e56dc_b59d8fd4e92d49e49ae904b51d0a7187~mv2.jpg'
    },
    {
        //Diane
        image: 'https://static.wixstatic.com/media/6e56dc_f518d61d55a54c2cbf3042965bc01769~mv2.jpg/v1/crop/x_0,y_12,w_635,h_887/fill/w_159,h_222,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/IMG_2220_JPG.jpg'
    },
    {
        //Molly
        image: 'https://static.wixstatic.com/media/6e56dc_b682d97884a345fb822267ea4bdba0ac~mv2.jpeg/v1/crop/x_65,y_0,w_350,h_480/fill/w_162,h_222,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/mmilazzo_headshot.jpeg'
    },
    {
        //Rene
        image: 'https://static.wixstatic.com/media/6e56dc_997862630d6d4065b681f00543aa4427~mv2.jpg/v1/crop/x_0,y_19,w_155,h_212/fill/w_162,h_222,al_c,lg_1,q_80,enc_auto/FullSizeRender.jpg'
    },
    {
        //Krista
        image: 'https://static.wixstatic.com/media/6e56dc_edcc73bb300945a1974935a7ee5d2c9f~mv2.jpg/v1/crop/x_25,y_0,w_1056,h_1478/fill/w_159,h_222,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/2021-08-29%2010_13_28_788-0700.jpg'
    },
    {
        //Allen
        image: 'https://static.wixstatic.com/media/6e56dc_5c2e378638aa43ada035022c89839ab4~mv2.jpg/v1/crop/x_85,y_25,w_363,h_526/fill/w_162,h_222,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/6e56dc_5c2e378638aa43ada035022c89839ab4~mv2.jpg'
    },
    {
        //Shahpoor
        image: 'https://static.wixstatic.com/media/6e56dc_6ab61f7b48174b98a60cb98c7ec5a554~mv2.jpg/v1/crop/x_291,y_132,w_183,h_251/fill/w_162,h_222,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/6e56dc_6ab61f7b48174b98a60cb98c7ec5a554~mv2.jpg'
    },
    {
        //Sayed
        image: 'https://static.wixstatic.com/media/6e56dc_c47788604ac14f41b7e80b78d0799e95~mv2.jpg/v1/crop/x_65,y_106,w_364,h_498/fill/w_164,h_222,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/img_3060.jpg'
    },
    
]

export default teamSlideData