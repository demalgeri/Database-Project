
const Translate = () => {

    return (
        <>  
            <div id="google_translate_element">
                <div>Translate:</div>
            </div>
        </>
    )
}

export default Translate