/*
    This component contains all of the slide data for the main slideshow. add images here by creating 
    a new index in the object.
*/

const slideData = [
    {
        image: 'https://i.imgur.com/1GKYSV1.jpg'
    }, 
    {
        image: 'https://i.imgur.com/rkfKCKN.jpg'
    },
    {
        image: 'https://i.imgur.com/5PyflYv.jpg'
    },
    {
        image: 'https://i.imgur.com/690jaFo.jpg'
    }
]

export default slideData